//
//  copiapetlistTests.swift
//  copiapetlistTests
//
//  Created by João Marcelo Colombini Cardonha on 28/12/24.
//

import Testing
@testable import copiapetlist

struct copiapetlistTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
